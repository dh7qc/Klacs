from Tkinter import *

class Application(Frame):

    def __init__(self, master = None):
        Frame.__init__(self, master)
        self.master.title("KLACS")
        self.master.resizable(width=False, height=False)
        self.master.minsize(1080,720)
        self.master.maxsize(1080,720)
        self.pack()
        self.createWidgets()
        return

    def createWidgets(self):
        memeButton = Button(self.master, text = "CLICK HERE FOR MEMES", command = self.master.quit)
        memeButton.pack({"side":"top"})
        return
