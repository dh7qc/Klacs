from Tkinter import *
from klacsGUI import *

def main():
    root = Tk()
    app = Application(master = root)
    app.mainloop()

    return

main()